import { TypeAnnotation } from "../ast/nodes.js";

/**
 * Builds a union from a list of member types, flattening nested unions and
 * collapsing structural duplicates (so `string | string` is just `string`,
 * and `(string | number) | number` is `string | number`, not three
 * members). Order is first-seen, so error messages and formatting stay
 * predictable across calls with the same effective input.
 *
 * This is the one general-purpose constructor for union types — both
 * `T | U` and `T?` (sugar for `T | none`) in the parser go through it, and
 * so does every inference site that discovers a value can be more than one
 * shape (mixed-type arrays, functions with multiple return types). See
 * docs/type-intelligence-roadmap.md §5, Layer 2.
 */
export function makeUnion(members: TypeAnnotation[]): TypeAnnotation {
  const flattened: TypeAnnotation[] = [];
  for (const member of members) {
    if (typeof member === "object" && member.kind === "union") {
      flattened.push(...member.types);
    } else {
      flattened.push(member);
    }
  }

  const deduped: TypeAnnotation[] = [];
  for (const candidate of flattened) {
    if (!deduped.some(existing => sameType(existing, candidate))) {
      deduped.push(candidate);
    }
  }

  return deduped.length === 1 ? deduped[0]! : { kind: "union", types: deduped };
}

/**
 * Strict structural equality — "is this literally the same type", not "can
 * a value of one be used where the other is expected". Two unions are the
 * same type only if they have the same members (order-independent); a
 * union is never the same type as a bare member, even if it only has one
 * effective member after dedup (makeUnion already collapses those, so a
 * genuine `{ kind: "union" }` here always has 2+ distinct members).
 *
 * Used where two independently-written or independently-inferred shapes
 * must match exactly: model republish conflicts, array-element
 * homogeneity at the representation level, record field comparison. For
 * "is this value allowed where that type is expected", use
 * `isAssignableTo` instead.
 */
export function sameType(left: TypeAnnotation, right: TypeAnnotation): boolean {
  if (left === "any" || right === "any") return true;

  if (typeof left === "string" && typeof right === "string") {
    return left === right;
  }
  if (typeof left === "string" || typeof right === "string") {
    return false;
  }
  if (left.kind !== right.kind) {
    return false;
  }

  if (left.kind === "array" && right.kind === "array") {
    return sameType(left.elementType, right.elementType);
  }

  if (left.kind === "record" && right.kind === "record") {
    const leftKeys = Object.keys(left.fields);
    const rightKeys = Object.keys(right.fields);
    if (leftKeys.length !== rightKeys.length) return false;
    return leftKeys.every(key => {
      const rightFieldType = right.fields[key];
      return rightFieldType !== undefined && sameType(left.fields[key]!, rightFieldType);
    });
  }

  if (left.kind === "union" && right.kind === "union") {
    if (left.types.length !== right.types.length) return false;
    return left.types.every(l => right.types.some(r => sameType(l, r)));
  }

  return false;
}

/**
 * Structural compatibility — "can a value of type `from` be used where
 * `to` is expected". This is what TypeScript-style inference needs and
 * `sameType` deliberately doesn't provide: `string` is assignable to
 * `string | number`, but the two are not the *same* type.
 *
 * This is the Layer 2 assignability check the roadmap calls for (§5): it's
 * what lets a declaration, assignment, argument, or return value be a
 * member of a wider union than it was written against, without requiring
 * the developer to spell out the union everywhere a narrower piece of it
 * shows up.
 */
export function isAssignableTo(from: TypeAnnotation, to: TypeAnnotation): boolean {
  if (from === "any" || to === "any") return true;

  // A union value is assignable to `to` only if every one of its members
  // is — the caller might see any of them, so `to` has to accept them all.
  if (typeof from === "object" && from.kind === "union") {
    return from.types.every(member => isAssignableTo(member, to));
  }

  // A non-union value is assignable to a union target if it's assignable
  // to at least one member.
  if (typeof to === "object" && to.kind === "union") {
    return to.types.some(member => isAssignableTo(from, member));
  }

  if (typeof from === "string" || typeof to === "string") {
    return from === to;
  }

  if (from.kind !== to.kind) return false;

  if (from.kind === "array" && to.kind === "array") {
    return isAssignableTo(from.elementType, to.elementType);
  }

  if (from.kind === "record" && to.kind === "record") {
    const fromKeys = Object.keys(from.fields);
    const toKeys = Object.keys(to.fields);
    if (fromKeys.length !== toKeys.length) return false;
    return toKeys.every(key => {
      const fromFieldType = from.fields[key];
      return fromFieldType !== undefined && isAssignableTo(fromFieldType, to.fields[key]!);
    });
  }

  return false;
}

export function formatType(type: TypeAnnotation | undefined): string {
  if (!type) return "unknown";
  if (type === "any") return "any";
  if (typeof type === "string") {
    return type;
  }
  if (type.kind === "array") {
    return `${formatType(type.elementType)}[]`;
  }
  if (type.kind === "record") {
    const fields = Object.entries(type.fields)
      .map(([key, fieldType]) => `${key}: ${formatType(fieldType)}`)
      .join(", ");
    return `{ ${fields} }`;
  }
  if (type.kind === "union") {
    // `T | none` prints back as `T?` — the sugar the developer would have
    // written, not the desugared form the checker reasons about.
    if (type.types.length === 2 && type.types.includes("none")) {
      const other = type.types.find(t => t !== "none")!;
      return `${formatType(other)}?`;
    }
    return type.types.map(formatType).join(" | ");
  }
  return "unknown";
}

function levenshtein(a: string, b: string): number {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const grid: number[][] = Array.from({ length: rows }, () => new Array<number>(cols).fill(0));

  for (let i = 0; i < rows; i++) grid[i]![0] = i;
  for (let j = 0; j < cols; j++) grid[0]![j] = j;

  for (let i = 1; i < rows; i++) {
    for (let j = 1; j < cols; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      grid[i]![j] = Math.min(
        grid[i - 1]![j]! + 1,
        grid[i]![j - 1]! + 1,
        grid[i - 1]![j - 1]! + cost,
      );
    }
  }

  return grid[rows - 1]![cols - 1]!;
}

/**
 * Finds the closest name to `target` among `candidates`, for "did you mean"
 * hints. Only suggests when the typo is plausibly close — short random
 * unrelated names shouldn't get suggested just because nothing else matched.
 */
export function closestMatch(target: string, candidates: string[]): string | undefined {
  let best: string | undefined;
  let bestDistance = Infinity;

  for (const candidate of candidates) {
    if (candidate === target) continue;
    const distance = levenshtein(target, candidate);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = candidate;
    }
  }

  const threshold = Math.max(2, Math.floor(target.length / 3));
  return bestDistance <= threshold ? best : undefined;
}

export type ShapeDiffEntry =
  | { kind: "added"; field: string; type: TypeAnnotation }
  | { kind: "removed"; field: string; type: TypeAnnotation }
  | { kind: "changed"; field: string; from: TypeAnnotation; to: TypeAnnotation };

/**
 * Field-by-field diff between two record shapes — used to explain *why*
 * two `model` declarations of the same name conflict, instead of just
 * saying "different shape" and leaving the reader to spot it themselves.
 */
export function diffShapes(previous: TypeAnnotation, next: TypeAnnotation): ShapeDiffEntry[] {
  if (typeof previous === "string" || typeof next === "string") return [];
  if (previous.kind !== "record" || next.kind !== "record") return [];

  const entries: ShapeDiffEntry[] = [];
  const previousKeys = Object.keys(previous.fields);
  const nextKeys = Object.keys(next.fields);

  for (const key of nextKeys) {
    if (!(key in previous.fields)) {
      entries.push({ kind: "added", field: key, type: next.fields[key]! });
    }
  }
  for (const key of previousKeys) {
    if (!(key in next.fields)) {
      entries.push({ kind: "removed", field: key, type: previous.fields[key]! });
    }
  }
  for (const key of previousKeys) {
    if (key in next.fields && !sameType(previous.fields[key]!, next.fields[key]!)) {
      entries.push({ kind: "changed", field: key, from: previous.fields[key]!, to: next.fields[key]! });
    }
  }

  return entries;
}

export function formatShapeDiff(entries: ShapeDiffEntry[]): string {
  return entries
    .map(entry => {
      if (entry.kind === "added") return `  + ${entry.field}: ${formatType(entry.type)}`;
      if (entry.kind === "removed") return `  - ${entry.field}: ${formatType(entry.type)}`;
      return `  ~ ${entry.field}: ${formatType(entry.from)} -> ${formatType(entry.to)}`;
    })
    .join("\n");
}
