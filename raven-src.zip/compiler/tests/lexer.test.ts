import { describe, it, expect } from "vitest";
import { tokenize, TokenKind } from "../src/lexer/token.js";

describe("lexer", () => {
  it("tokenizes a print statement", () => {
    const tokens = tokenize(`print("hi")`);
    const kinds = tokens.map(t => t.kind);
    expect(kinds).toEqual([
      TokenKind.Keyword,
      TokenKind.Punctuation,
      TokenKind.String,
      TokenKind.Punctuation,
      TokenKind.EOF,
    ]);
  });

  it("tokenizes math and comparison operators", () => {
    const tokens = tokenize(`2 + 3 * 4 == 14`);
    const values = tokens.map(t => t.value);
    expect(values).toEqual(["2", "+", "3", "*", "4", "==", "14", ""]);
  });

  it("tokenizes a let statement", () => {
    const tokens = tokenize(`let x = "hi"`);
    expect(tokens.map(t => t.kind)).toEqual([
      TokenKind.Keyword,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.String,
      TokenKind.EOF,
    ]);
  });

  it("tokenizes a const statement", () => {
    const tokens = tokenize(`const x = "hi"`);
    expect(tokens.map(t => t.kind)).toEqual([
      TokenKind.Keyword,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.String,
      TokenKind.EOF,
    ]);
  });

  it("tokenizes if/then/else/end as keywords", () => {
    const tokens = tokenize(`if age > 18 then print(age) end`);
    const kinds = tokens.filter(t => ["if", "then", "end"].includes(t.value)).map(t => t.kind);
    expect(kinds.every(k => k === TokenKind.Keyword)).toBe(true);
  });

  it("tokenizes identifiers separately from keywords", () => {
    const tokens = tokenize(`foo`);
    expect(tokens[0]!.kind).toBe(TokenKind.Identifier);
    expect(tokens[0]!.value).toBe("foo");
  });

  it("extracts string values without quotes", () => {
    const tokens = tokenize(`print("Hello, World!")`);
    const str = tokens.find(t => t.kind === TokenKind.String);
    expect(str?.value).toBe("Hello, World!");
  });

  it("tokenizes true and false as keywords", () => {
    const tokens = tokenize(`let isReady = true`);
    const boolToken = tokens.find(t => t.value === "true");
    expect(boolToken?.kind).toBe(TokenKind.Keyword);
  });

  it("tokenizes a number literal", () => {
    const tokens = tokenize(`let age = 5`);
    const numberToken = tokens.find(t => t.kind === TokenKind.Number);
    expect(numberToken?.value).toBe("5");
  });

  it("tokenizes a typed let statement", () => {
    const tokens = tokenize(`let x: string = "hi"`);
    expect(tokens.map(t => t.kind)).toEqual([
      TokenKind.Keyword,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.String,
      TokenKind.EOF,
    ]);
  });

  it("tokenizes a typed const statement", () => {
    const tokens = tokenize(`const x: string = "hi"`);
    expect(tokens.map(t => t.kind)).toEqual([
      TokenKind.Keyword,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.Identifier,
      TokenKind.Punctuation,
      TokenKind.String,
      TokenKind.EOF,
    ]);
  });

  it("skips whitespace", () => {
    const tokens = tokenize(`  print  (  "hi"  )  `);
    expect(tokens.length).toBe(5);
  });
});