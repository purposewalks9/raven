#!/usr/bin/env node
"use strict";

// src/server.ts
var import_node3 = require("vscode-languageserver/node.js");
var import_vscode_languageserver_textdocument = require("vscode-languageserver-textdocument");

// ../../compiler/dist/chunk-MVSCC6JV.js
var KEYWORDS = /* @__PURE__ */ new Set([
  "print",
  "let",
  "const",
  "true",
  "false",
  "if",
  "then",
  "else",
  "end",
  "and",
  "or",
  "not",
  "while",
  "do",
  "fn",
  "return",
  "break",
  "continue",
  "model",
  "import",
  "from"
]);
var TWO_CHARACTER_OPERATORS = /* @__PURE__ */ new Set(["==", "!=", "<=", ">="]);
var SINGLE_CHARACTER_PUNCTUATION = /* @__PURE__ */ new Set([
  "+",
  "-",
  "*",
  "/",
  "%",
  "=",
  "<",
  ">",
  "!",
  ":",
  ",",
  ".",
  ";",
  "(",
  ")",
  "{",
  "}",
  "[",
  "]"
]);
function tokenize(source, file = "<anonymous>") {
  const tokens = [];
  let pos = 0;
  let line = 1;
  let column = 1;
  const location = (start = pos, end = pos) => ({ file, line, column, start, end });
  const advance = () => {
    const char = source[pos++] ?? "";
    if (char === "\n") {
      line++;
      column = 1;
    } else {
      column++;
    }
    return char;
  };
  const add = (kind, value, start, end = pos) => {
    tokens.push({ kind, value, location: { ...start, end } });
  };
  while (pos < source.length) {
    const char = source[pos] ?? "";
    if (/\s/.test(char)) {
      advance();
      continue;
    }
    if (char === "/" && source[pos + 1] === "/") {
      while (pos < source.length && source[pos] !== "\n") advance();
      continue;
    }
    if (char === "/" && source[pos + 1] === "*") {
      const start2 = location(pos, pos);
      advance();
      advance();
      while (pos < source.length && !(source[pos] === "*" && source[pos + 1] === "/")) advance();
      if (pos >= source.length) throw new Error(`${start2.line}:${start2.column} Unterminated block comment`);
      advance();
      advance();
      continue;
    }
    const start = location(pos, pos);
    const pair = source.slice(pos, pos + 2);
    if (TWO_CHARACTER_OPERATORS.has(pair)) {
      advance();
      advance();
      add("Punctuation", pair, start);
      continue;
    }
    if (SINGLE_CHARACTER_PUNCTUATION.has(char)) {
      advance();
      add("Punctuation", char, start);
      continue;
    }
    if (char === '"') {
      advance();
      let value = "";
      while (pos < source.length && source[pos] !== '"') {
        if (source[pos] === "\n") throw new Error(`${start.line}:${start.column} Unterminated string`);
        value += advance();
      }
      if (source[pos] !== '"') throw new Error(`${start.line}:${start.column} Unterminated string`);
      advance();
      add("String", value, start);
      continue;
    }
    if (/[0-9]/.test(char)) {
      let value = "";
      while (pos < source.length && /[0-9]/.test(source[pos] ?? "")) value += advance();
      if (source[pos] === "." && /[0-9]/.test(source[pos + 1] ?? "")) {
        value += advance();
        while (pos < source.length && /[0-9]/.test(source[pos] ?? "")) value += advance();
      }
      add("Number", value, start);
      continue;
    }
    if (/[a-zA-Z_]/.test(char)) {
      let value = "";
      while (pos < source.length && /[a-zA-Z0-9_]/.test(source[pos] ?? "")) value += advance();
      add(KEYWORDS.has(value) ? "Keyword" : "Identifier", value, start);
      continue;
    }
    throw new Error(`${start.line}:${start.column} Unexpected character '${char}'`);
  }
  tokens.push({ kind: "EOF", value: "", location: location(pos, pos) });
  return tokens;
}
var Parser = class {
  constructor(tokens) {
    this.tokens = tokens;
  }
  tokens;
  pos = 0;
  parseProgram() {
    const body = [];
    while (this.peek().kind !== "EOF") {
      body.push(this.parseStatement());
    }
    return { type: "Program", body, location: this.tokens[0]?.location ?? this.peek().location };
  }
  parseStatement() {
    if (this.checkKeyword("print")) return this.parsePrint();
    if (this.checkKeyword("let")) return this.parseLet();
    if (this.checkKeyword("const")) return this.parseConst();
    if (this.checkKeyword("model")) return this.parseModel();
    if (this.checkKeyword("import")) return this.parseImport();
    if (this.checkKeyword("if")) return this.parseIf();
    if (this.checkKeyword("while")) return this.parseWhile();
    if (this.checkKeyword("fn")) return this.parseFunctionDeclaration();
    if (this.checkKeyword("return")) return this.parseReturn();
    if (this.checkKeyword("break")) {
      const token = this.advance();
      return this.withLocation({ type: "BreakStatement" }, token.location);
    }
    if (this.checkKeyword("continue")) {
      const token = this.advance();
      return this.withLocation({ type: "ContinueStatement" }, token.location);
    }
    if (this.peek().kind === "Identifier" && this.tokens[this.pos + 1]?.value === "=") {
      return this.parseAssignment();
    }
    if (this.peek().kind === "Identifier" && this.tokens[this.pos + 1]?.value === "(") {
      const expression = this.parseExpression();
      return this.withLocation({ type: "ExpressionStatement", expression }, expression.location);
    }
    throw new Error(`Expected a statement, got: ${this.peek().value} (${this.peek().kind})`);
  }
  parsePrint() {
    const start = this.peek().location;
    this.expectKeyword("print");
    this.expect("(");
    const argument = this.parseExpression();
    this.expect(")");
    return this.withLocation({ type: "PrintStatement", argument }, start);
  }
  parseLet() {
    const start = this.peek().location;
    this.expectKeyword("let");
    const nameToken = this.peek();
    if (nameToken.kind !== "Identifier") {
      throw new Error("Expected an identifier after 'let'");
    }
    this.advance();
    let typeAnnotation;
    if (this.peek().value === ":") {
      this.advance();
      typeAnnotation = this.parseTypeAnnotation();
    }
    this.expect("=");
    const value = this.parseExpression();
    return this.withLocation({
      type: "VariableDeclaration",
      name: nameToken.value,
      value,
      typeAnnotation
    }, start);
  }
  parseConst() {
    const start = this.peek().location;
    this.expectKeyword("const");
    const nameToken = this.peek();
    if (nameToken.kind !== "Identifier") {
      throw new Error("Expected an identifier after 'const'");
    }
    this.advance();
    let typeAnnotation;
    if (this.peek().value === ":") {
      this.advance();
      typeAnnotation = this.parseTypeAnnotation();
    }
    this.expect("=");
    const value = this.parseExpression();
    return this.withLocation({
      type: "ConstantDeclaration",
      name: nameToken.value,
      value,
      typeAnnotation
    }, start);
  }
  parseModel() {
    const start = this.peek().location;
    this.expectKeyword("model");
    const nameToken = this.peek();
    if (nameToken.kind !== "Identifier") {
      throw new Error("Expected an identifier after 'model'");
    }
    this.advance();
    let typeAnnotation;
    if (this.peek().value === ":") {
      this.advance();
      typeAnnotation = this.parseTypeAnnotation();
    }
    this.expect("=");
    const value = this.parseExpression();
    const external = this.isExternalBinding(value);
    return this.withLocation({
      type: "ModelDeclaration",
      name: nameToken.value,
      value,
      typeAnnotation,
      external
    }, start);
  }
  // A model is "external" when it's bound to something outside the
  // project's own source — `database.users`, `api("/users")` — rather
  // than inferred from a literal written right here.
  isExternalBinding(expr) {
    if (expr.type === "CallExpression") {
      return expr.callee === "api" || expr.callee === "database";
    }
    if (expr.type === "MemberExpression") {
      let root = expr;
      while (root.type === "MemberExpression") root = root.object;
      return root.type === "Identifier" && (root.name === "database" || root.name === "api");
    }
    return false;
  }
  parseImport() {
    const start = this.peek().location;
    this.expectKeyword("import");
    const names = [];
    if (this.peek().value === "{") {
      this.advance();
      while (this.peek().value !== "}") {
        const nameToken = this.peek();
        if (nameToken.kind !== "Identifier") {
          throw new Error("Expected an identifier in import list");
        }
        this.advance();
        names.push(nameToken.value);
        if (this.peek().value === ",") {
          this.advance();
        }
      }
      this.expect("}");
    } else {
      const nameToken = this.peek();
      if (nameToken.kind !== "Identifier") {
        throw new Error("Expected an identifier after 'import'");
      }
      this.advance();
      names.push(nameToken.value);
    }
    this.expectKeyword("from");
    const sourceToken = this.peek();
    if (sourceToken.kind !== "String") {
      throw new Error("Expected a string module path after 'from'");
    }
    this.advance();
    return this.withLocation({ type: "ImportDeclaration", names, source: sourceToken.value }, start);
  }
  parseAssignment() {
    const nameToken = this.advance();
    const start = nameToken.location;
    this.expect("=");
    const value = this.parseExpression();
    return this.withLocation({ type: "Assignment", name: nameToken.value, value }, start);
  }
  parseIf() {
    const start = this.peek().location;
    this.expectKeyword("if");
    const condition = this.parseExpression();
    this.expectKeyword("then");
    const consequent = this.parseBlockUntil(["else", "end"]);
    let alternate;
    if (this.checkKeyword("else")) {
      this.advance();
      alternate = this.parseBlockUntil(["end"]);
    }
    this.expectKeyword("end");
    return alternate === void 0 ? this.withLocation({ type: "IfStatement", condition, consequent }, start) : this.withLocation({ type: "IfStatement", condition, consequent, alternate }, start);
  }
  parseWhile() {
    const start = this.peek().location;
    this.expectKeyword("while");
    const condition = this.parseExpression();
    this.expectKeyword("do");
    const body = this.parseBlockUntil(["end"]);
    this.expectKeyword("end");
    return this.withLocation({ type: "WhileStatement", condition, body }, start);
  }
  parseFunctionDeclaration() {
    const start = this.peek().location;
    this.expectKeyword("fn");
    const nameToken = this.peek();
    if (nameToken.kind !== "Identifier") {
      throw new Error("Expected a function name after 'fn'");
    }
    this.advance();
    this.expect("(");
    const parameters = [];
    while (this.peek().value !== ")") {
      const paramName = this.peek();
      if (paramName.kind !== "Identifier") {
        throw new Error("Expected a parameter name");
      }
      this.advance();
      this.expect(":");
      const typeAnnotation = this.parseTypeAnnotation();
      parameters.push({ name: paramName.value, typeAnnotation, location: paramName.location });
      if (this.peek().value === ",") {
        this.advance();
      }
    }
    this.expect(")");
    this.expect(":");
    const returnType = this.parseTypeAnnotation();
    const body = this.parseBlockUntil(["end"]);
    this.expectKeyword("end");
    return this.withLocation({
      type: "FunctionDeclaration",
      name: nameToken.value,
      parameters,
      returnType,
      body
    }, start);
  }
  parseReturn() {
    const start = this.peek().location;
    this.expectKeyword("return");
    const value = this.parseExpression();
    return this.withLocation({ type: "ReturnStatement", value }, start);
  }
  parseBlockUntil(stopKeywords) {
    const statements = [];
    while (!stopKeywords.some((word) => this.checkKeyword(word)) && this.peek().kind !== "EOF") {
      statements.push(this.parseStatement());
    }
    return statements;
  }
  parseExpression() {
    return this.parseLogical();
  }
  parseLogical() {
    let left = this.parseComparison();
    while (this.checkKeyword("and") || this.checkKeyword("or")) {
      const operator = this.advance().value;
      const right = this.parseComparison();
      left = this.withLocation({ type: "BinaryExpression", operator, left, right }, left.location);
    }
    return left;
  }
  parseComparison() {
    let left = this.parseAdditive();
    while (["==", "!=", "<", "<=", ">", ">="].includes(this.peek().value)) {
      const operator = this.advance().value;
      const right = this.parseAdditive();
      left = this.withLocation({ type: "BinaryExpression", operator, left, right }, left.location);
    }
    return left;
  }
  parseAdditive() {
    let left = this.parseMultiplicative();
    while (this.peek().value === "+" || this.peek().value === "-") {
      const operator = this.advance().value;
      const right = this.parseMultiplicative();
      left = this.withLocation({ type: "BinaryExpression", operator, left, right }, left.location);
    }
    return left;
  }
  parseMultiplicative() {
    let left = this.parsePrimary();
    while (this.peek().value === "*" || this.peek().value === "/" || this.peek().value === "%") {
      const operator = this.advance().value;
      const right = this.parsePrimary();
      left = this.withLocation({ type: "BinaryExpression", operator, left, right }, left.location);
    }
    return left;
  }
  parsePrimary() {
    let expr = this.parsePrimaryBase();
    while (this.peek().value === "[" || this.peek().value === ".") {
      if (this.peek().value === "[") {
        this.advance();
        const index = this.parseExpression();
        this.expect("]");
        expr = this.withLocation({ type: "IndexExpression", array: expr, index }, expr.location);
      } else {
        this.advance();
        const propertyToken = this.peek();
        if (propertyToken.kind !== "Identifier") {
          throw new Error(`Expected a property name after '.', got: ${propertyToken.value} (${propertyToken.kind})`);
        }
        this.advance();
        expr = this.withLocation({ type: "MemberExpression", object: expr, property: propertyToken.value }, expr.location);
      }
    }
    return expr;
  }
  parsePrimaryBase() {
    const token = this.peek();
    if (this.checkKeyword("not")) {
      this.advance();
      const argument = this.parsePrimary();
      return this.withLocation({ type: "UnaryExpression", operator: "not", argument }, token.location);
    }
    if (this.peek().value === "(") {
      this.advance();
      const expression = this.parseExpression();
      this.expect(")");
      return expression;
    }
    if (token.kind === "Identifier" && this.tokens[this.pos + 1]?.value === "(") {
      return this.parseCall();
    }
    if (token.kind === "String") {
      this.advance();
      return this.withLocation({ type: "StringLiteral", value: token.value }, token.location);
    }
    if (token.kind === "Identifier") {
      this.advance();
      return this.withLocation({ type: "Identifier", name: token.value }, token.location);
    }
    if (token.kind === "Number") {
      this.advance();
      return this.withLocation({ type: "NumberLiteral", value: Number(token.value) }, token.location);
    }
    if (token.kind === "Keyword" && (token.value === "true" || token.value === "false")) {
      this.advance();
      return this.withLocation({ type: "BooleanLiteral", value: token.value === "true" }, token.location);
    }
    if (this.peek().value === "[") {
      return this.parseArrayLiteral();
    }
    if (this.peek().value === "{") {
      return this.parseObjectLiteral();
    }
    throw new Error(`Expected a string, number, boolean, identifier, or function call, got: ${token.value} (${token.kind})`);
  }
  parseCall() {
    const nameToken = this.advance();
    this.expect("(");
    const args = [];
    while (this.peek().value !== ")") {
      args.push(this.parseExpression());
      if (this.peek().value === ",") {
        this.advance();
      }
    }
    this.expect(")");
    return this.withLocation({ type: "CallExpression", callee: nameToken.value, arguments: args }, nameToken.location);
  }
  parseArrayLiteral() {
    const start = this.peek().location;
    this.expect("[");
    const elements = [];
    while (this.peek().value !== "]") {
      elements.push(this.parseExpression());
      if (this.peek().value === ",") {
        this.advance();
      }
    }
    this.expect("]");
    return this.withLocation({ type: "ArrayLiteral", elements }, start);
  }
  parseObjectLiteral() {
    const start = this.peek().location;
    this.expect("{");
    const properties = [];
    while (this.peek().value !== "}") {
      const keyToken = this.peek();
      if (keyToken.kind !== "Identifier") {
        throw new Error(`Expected a property name, got: ${keyToken.value} (${keyToken.kind})`);
      }
      this.advance();
      this.expect(":");
      const value = this.parseExpression();
      properties.push({ key: keyToken.value, value });
      if (this.peek().value === ",") {
        this.advance();
      }
    }
    this.expect("}");
    return this.withLocation({ type: "ObjectLiteral", properties }, start);
  }
  parseTypeAnnotation() {
    const token = this.peek();
    if (token.kind !== "Identifier") {
      throw new Error(`Expected a type name, got: ${token.value} (${token.kind})`);
    }
    this.advance();
    if (token.value === "array") {
      this.expect("<");
      const elementType = this.parseTypeAnnotation();
      this.expect(">");
      return { kind: "array", elementType };
    }
    return token.value;
  }
  withLocation(node, location = this.peek().location) {
    return { ...node, location };
  }
  peek() {
    const token = this.tokens[this.pos];
    if (!token) {
      throw new Error("Unexpected end of file");
    }
    return token;
  }
  advance() {
    const token = this.tokens[this.pos];
    if (!token) {
      throw new Error("Unexpected end of file");
    }
    this.pos++;
    return token;
  }
  checkKeyword(word) {
    const token = this.peek();
    return token.kind === "Keyword" && token.value === word;
  }
  expectKeyword(word) {
    if (!this.checkKeyword(word)) {
      throw new Error(`Expected '${word}'`);
    }
    this.advance();
  }
  expect(value) {
    const token = this.peek();
    if (token.value !== value) {
      throw new Error(`Expected '${value}'`);
    }
    this.advance();
  }
};
function contains(loc, offset) {
  return offset >= loc.start && offset <= loc.end;
}
var Binder = class {
  bindings = [];
  /** Call once, at the same point the checker declares a symbol. */
  declare(name, kind, type, location) {
    const binding = { name, kind, type, declaration: location, references: [] };
    this.bindings.push(binding);
    return binding;
  }
  /** Call at the same point the checker resolves a lookup for a use. */
  reference(binding, location) {
    if (binding) binding.references.push(location);
  }
  all() {
    return this.bindings;
  }
  bindingAt(offset) {
    let match;
    for (const binding of this.bindings) {
      if (contains(binding.declaration, offset)) match = binding;
      else if (binding.references.some((ref) => contains(ref, offset))) match = binding;
    }
    return match;
  }
};
var DiagnosticBag = class {
  diagnostics = [];
  error(message, location, hint) {
    this.diagnostics.push(hint ? { severity: "error", message, location, hint } : { severity: "error", message, location });
  }
  warning(message, location, hint) {
    this.diagnostics.push(hint ? { severity: "warning", message, location, hint } : { severity: "warning", message, location });
  }
  all() {
    return [...this.diagnostics];
  }
  hasErrors() {
    return this.diagnostics.some((diagnostic) => diagnostic.severity === "error");
  }
};
var SymbolTable = class {
  scopes = [/* @__PURE__ */ new Map()];
  enterScope() {
    this.scopes.push(/* @__PURE__ */ new Map());
  }
  exitScope() {
    if (this.scopes.length === 1) {
      throw new Error("Cannot exit the global scope.");
    }
    this.scopes.pop();
  }
  declare(name, info) {
    const current = this.scopes[this.scopes.length - 1];
    if (!current) {
      throw new Error("No active scope.");
    }
    if (current.has(name)) {
      return false;
    }
    current.set(name, info);
    return true;
  }
  lookup(name) {
    for (let i = this.scopes.length - 1; i >= 0; i--) {
      const symbol = this.scopes[i]?.get(name);
      if (symbol) {
        return symbol;
      }
    }
    return void 0;
  }
  has(name) {
    return this.lookup(name) !== void 0;
  }
  isConstant(name) {
    return this.lookup(name)?.constant ?? false;
  }
  getScopeDepth() {
    return this.scopes.length;
  }
  hasInCurrentScope(name) {
    const current = this.scopes[this.scopes.length - 1];
    return current?.has(name) ?? false;
  }
  /** Every name visible right now, from every open scope, for typo suggestions. */
  allNames() {
    const names = /* @__PURE__ */ new Set();
    for (const scope of this.scopes) {
      for (const name of scope.keys()) names.add(name);
    }
    return [...names];
  }
};
function sameType(left, right) {
  if (left === "any" || right === "any") return true;
  if (typeof left === "string" && typeof right === "string") {
    return left === right;
  }
  if (typeof left === "string" || typeof right === "string") {
    return false;
  }
  if (left.kind !== right.kind) {
    return false;
  }
  if (left.kind === "array" && right.kind === "array") {
    return sameType(left.elementType, right.elementType);
  }
  if (left.kind === "record" && right.kind === "record") {
    const leftKeys = Object.keys(left.fields);
    const rightKeys = Object.keys(right.fields);
    if (leftKeys.length !== rightKeys.length) return false;
    return leftKeys.every((key) => {
      const rightFieldType = right.fields[key];
      return rightFieldType !== void 0 && sameType(left.fields[key], rightFieldType);
    });
  }
  return false;
}
function formatType(type) {
  if (!type) return "unknown";
  if (type === "any") return "any";
  if (typeof type === "string") {
    return type;
  }
  if (type.kind === "array") {
    return `${formatType(type.elementType)}[]`;
  }
  if (type.kind === "record") {
    const fields = Object.entries(type.fields).map(([key, fieldType]) => `${key}: ${formatType(fieldType)}`).join(", ");
    return `{ ${fields} }`;
  }
  return "unknown";
}
function levenshtein(a, b) {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const grid = Array.from({ length: rows }, () => new Array(cols).fill(0));
  for (let i = 0; i < rows; i++) grid[i][0] = i;
  for (let j = 0; j < cols; j++) grid[0][j] = j;
  for (let i = 1; i < rows; i++) {
    for (let j = 1; j < cols; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      grid[i][j] = Math.min(
        grid[i - 1][j] + 1,
        grid[i][j - 1] + 1,
        grid[i - 1][j - 1] + cost
      );
    }
  }
  return grid[rows - 1][cols - 1];
}
function closestMatch(target, candidates) {
  let best;
  let bestDistance = Infinity;
  for (const candidate of candidates) {
    if (candidate === target) continue;
    const distance = levenshtein(target, candidate);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = candidate;
    }
  }
  const threshold = Math.max(2, Math.floor(target.length / 3));
  return bestDistance <= threshold ? best : void 0;
}
var TypeChecker = class {
  symbolTable = new SymbolTable();
  diagnostics = new DiagnosticBag();
  binder = new Binder();
  registry;
  file;
  importedFunctions;
  functionSignatures = /* @__PURE__ */ new Map([
    ["len", { params: [{ kind: "array", elementType: "any" }], returnType: "number" }],
    ["abs", { params: ["number"], returnType: "number" }],
    ["sqrt", { params: ["number"], returnType: "number" }],
    ["toString", { params: ["any"], returnType: "string" }]
  ]);
  currentReturnType;
  inferredReturnTypes;
  constructor(options = {}) {
    this.registry = options.registry;
    this.file = options.file ?? "<anonymous>";
    this.importedFunctions = options.importedFunctions ?? /* @__PURE__ */ new Map();
  }
  check(program) {
    this.diagnostics = new DiagnosticBag();
    this.binder = new Binder();
    for (const stmt of program.body) {
      this.checkStatement(stmt);
    }
    return this.diagnostics.all();
  }
  getBinder() {
    return this.binder;
  }
  /** Every top-level function this file makes available to `import`. */
  getExportedFunctions() {
    const result = /* @__PURE__ */ new Map();
    for (const [name, sig] of this.functionSignatures) {
      if (sig.binding) result.set(name, { params: sig.params, returnType: sig.returnType });
    }
    return result;
  }
  checkStatement(node) {
    switch (node.type) {
      case "VariableDeclaration":
      case "ConstantDeclaration":
        this.checkDeclaration(node);
        break;
      case "ModelDeclaration":
        this.checkModelDeclaration(node);
        break;
      case "ImportDeclaration":
        this.checkImportDeclaration(node);
        break;
      case "PrintStatement":
        this.checkExpression(node.argument);
        break;
      case "Assignment":
        this.checkAssignment(node);
        break;
      case "IfStatement":
        this.checkIfStatement(node);
        break;
      case "WhileStatement":
        this.checkWhileStatement(node);
        break;
      case "FunctionDeclaration":
        this.checkFunctionDeclaration(node);
        break;
      case "ReturnStatement": {
        const returnType = this.checkExpression(node.value);
        if (this.inferredReturnTypes) {
          this.inferredReturnTypes.push(returnType);
        } else if (this.currentReturnType && !this.sameType(returnType, this.currentReturnType)) {
          this.diagnostics.error(
            `Return type mismatch: expected '${this.formatType(this.currentReturnType)}', got '${this.formatType(returnType)}'`,
            node.location
          );
        }
        break;
      }
      case "ExpressionStatement":
        this.checkExpression(node.expression);
        break;
      case "BreakStatement":
      case "ContinueStatement":
        break;
      default:
        throw new Error(`Unknown statement type: ${node.type}`);
    }
  }
  checkDeclaration(node) {
    const actualType = this.inferType(node.value);
    if (node.typeAnnotation && !this.sameType(node.typeAnnotation, actualType)) {
      this.diagnostics.error(
        `Type mismatch in declaration of '${node.name}': expected '${this.formatType(node.typeAnnotation)}', but got '${this.formatType(actualType)}'`,
        node.location,
        `Either change the annotation to '${this.formatType(actualType)}' or change the value to match '${this.formatType(node.typeAnnotation)}'.`
      );
    }
    const type = node.typeAnnotation ?? actualType;
    const constant = node.type === "ConstantDeclaration";
    const binding = this.binder.declare(node.name, constant ? "constant" : "variable", type, node.location);
    const success = this.symbolTable.declare(node.name, { type, constant, binding });
    if (!success) {
      this.diagnostics.error(`'${node.name}' has already been declared.`, node.location);
    }
  }
  checkModelDeclaration(node) {
    let type;
    if (node.external) {
      type = node.typeAnnotation ?? "any";
    } else {
      const actualType = this.inferType(node.value);
      if (node.typeAnnotation && !this.sameType(node.typeAnnotation, actualType)) {
        this.diagnostics.error(
          `Type mismatch in model '${node.name}': expected '${this.formatType(node.typeAnnotation)}', but got '${this.formatType(actualType)}'`,
          node.location
        );
      }
      type = node.typeAnnotation ?? actualType;
    }
    const binding = this.binder.declare(node.name, "model", type, node.location);
    const success = this.symbolTable.declare(node.name, { type, constant: true, binding });
    if (!success) {
      this.diagnostics.error(`'${node.name}' has already been declared.`, node.location);
    }
    if (this.registry) {
      const result = this.registry.publish(node.name, type, node.external, this.file, node.location);
      if (!result.ok) {
        this.diagnostics.error(
          result.message,
          node.location,
          `'${node.name}' was first published in ${result.existing.file}. Give this one a different name, or make both shapes match.`
        );
      }
    }
  }
  checkImportDeclaration(node) {
    for (const name of node.names) {
      const imported = this.importedFunctions.get(name);
      if (imported) {
        const binding = this.binder.declare(name, "function", imported.returnType, node.location);
        this.functionSignatures.set(name, { ...imported, binding });
        continue;
      }
      if (this.registry?.lookup(name)) {
        this.diagnostics.error(
          `'${name}' is a published model, not code \u2014 models don't need an import, just use the name directly.`,
          node.location
        );
        continue;
      }
      this.diagnostics.error(
        `Cannot resolve import '${name}' from '${node.source}'. Make sure it's declared as a top-level function there.`,
        node.location
      );
    }
  }
  checkAssignment(node) {
    const symbol = this.symbolTable.lookup(node.name);
    if (!symbol) {
      if (this.registry?.lookup(node.name)) {
        this.diagnostics.error(
          `Cannot reassign '${node.name}': it's a published model, which is read-only outside the file that declares it.`,
          node.location
        );
        return;
      }
      this.diagnostics.error(`Cannot assign to undeclared variable '${node.name}'`, node.location);
      return;
    }
    this.binder.reference(symbol.binding, node.location);
    if (symbol.constant) {
      this.diagnostics.error(
        `Cannot reassign constant '${node.name}' (declared with 'const')`,
        node.location,
        `Use 'let' instead of 'const' if '${node.name}' needs to change later.`
      );
      return;
    }
    const valueType = this.inferType(node.value);
    if (!this.sameType(valueType, symbol.type)) {
      this.diagnostics.error(
        `Type mismatch in assignment to '${node.name}': expected '${this.formatType(symbol.type)}', got '${this.formatType(valueType)}'`,
        node.location
      );
    }
  }
  checkIfStatement(node) {
    const conditionType = this.inferType(node.condition);
    if (conditionType !== "boolean" && conditionType !== "any") {
      this.diagnostics.error(
        `If condition must be a boolean, got '${this.formatType(conditionType)}'`,
        node.condition.location
      );
    }
    this.symbolTable.enterScope();
    for (const stmt of node.consequent) {
      this.checkStatement(stmt);
    }
    this.symbolTable.exitScope();
    if (node.alternate) {
      this.symbolTable.enterScope();
      for (const stmt of node.alternate) {
        this.checkStatement(stmt);
      }
      this.symbolTable.exitScope();
    }
  }
  checkWhileStatement(node) {
    const conditionType = this.inferType(node.condition);
    if (conditionType !== "boolean" && conditionType !== "any") {
      this.diagnostics.error(
        `While condition must be a boolean, got '${this.formatType(conditionType)}'`,
        node.condition.location
      );
    }
    this.symbolTable.enterScope();
    for (const stmt of node.body) {
      this.checkStatement(stmt);
    }
    this.symbolTable.exitScope();
  }
  checkFunctionDeclaration(node) {
    if (this.functionSignatures.has(node.name)) {
      this.diagnostics.error(`Function '${node.name}' has already been declared`, node.location);
    }
    const paramTypes = node.parameters.map((p) => p.typeAnnotation ?? "any");
    const isReturnTypeInferred = node.returnType === void 0;
    const functionBinding = this.binder.declare(node.name, "function", node.returnType ?? "any", node.location);
    const signature = {
      params: paramTypes,
      returnType: node.returnType ?? "any",
      binding: functionBinding
    };
    this.functionSignatures.set(node.name, signature);
    this.symbolTable.enterScope();
    const seenParameters = /* @__PURE__ */ new Set();
    const previousReturnType = this.currentReturnType;
    const previousInferredReturns = this.inferredReturnTypes;
    this.currentReturnType = isReturnTypeInferred ? void 0 : node.returnType;
    this.inferredReturnTypes = isReturnTypeInferred ? [] : void 0;
    for (const param of node.parameters) {
      if (seenParameters.has(param.name)) {
        this.diagnostics.error(
          `Duplicate parameter name '${param.name}' in function '${node.name}'`,
          node.location
        );
      }
      seenParameters.add(param.name);
      const paramType = param.typeAnnotation ?? "any";
      const paramBinding = this.binder.declare(param.name, "parameter", paramType, param.location ?? node.location);
      this.symbolTable.declare(param.name, { type: paramType, constant: false, binding: paramBinding });
    }
    for (const stmt of node.body) {
      this.checkStatement(stmt);
    }
    if (isReturnTypeInferred) {
      let inferred = "any";
      for (const returnType of this.inferredReturnTypes ?? []) {
        if (inferred === "any") {
          inferred = returnType;
        } else if (!this.sameType(inferred, returnType)) {
          this.diagnostics.error(
            `Function '${node.name}' returns different types in different places: '${this.formatType(inferred)}' and '${this.formatType(returnType)}'`,
            node.location,
            `Add an explicit return type annotation (e.g. ': ${this.formatType(inferred)}') to resolve the ambiguity.`
          );
        }
      }
      signature.returnType = inferred;
      functionBinding.type = inferred;
    }
    this.symbolTable.exitScope();
    this.currentReturnType = previousReturnType;
    this.inferredReturnTypes = previousInferredReturns;
  }
  checkExpression(node) {
    return this.inferType(node);
  }
  inferType(node) {
    switch (node.type) {
      case "StringLiteral":
        return "string";
      case "NumberLiteral":
        return "number";
      case "BooleanLiteral":
        return "boolean";
      case "Identifier": {
        const symbol = this.symbolTable.lookup(node.name);
        if (symbol) {
          this.binder.reference(symbol.binding, node.location);
          return symbol.type;
        }
        const published = this.registry?.lookup(node.name);
        if (published) {
          return published.type;
        }
        const suggestion = closestMatch(node.name, [
          ...this.symbolTable.allNames(),
          ...this.registry?.names() ?? []
        ]);
        this.diagnostics.error(
          `Undeclared variable '${node.name}'`,
          node.location,
          suggestion ? `Did you mean '${suggestion}'?` : void 0
        );
        return "any";
      }
      case "UnaryExpression": {
        const argType = this.inferType(node.argument);
        if (argType !== "boolean" && argType !== "any") {
          this.diagnostics.error(
            `Operator 'not' requires a boolean operand, got '${this.formatType(argType)}'`,
            node.location
          );
        }
        return "boolean";
      }
      case "CallExpression": {
        const signature = this.functionSignatures.get(node.callee);
        if (!signature) {
          const suggestion = closestMatch(node.callee, [...this.functionSignatures.keys()]);
          this.diagnostics.error(
            `Undeclared function '${node.callee}'`,
            node.location,
            suggestion ? `Did you mean '${suggestion}'?` : void 0
          );
          return "any";
        }
        this.binder.reference(signature.binding, node.location);
        if (node.arguments.length !== signature.params.length) {
          this.diagnostics.error(
            `Function '${node.callee}' expects ${signature.params.length} argument(s), but got ${node.arguments.length}`,
            node.location
          );
        }
        node.arguments.forEach((arg, i) => {
          const argType = this.inferType(arg);
          const expectedType = signature.params[i];
          if (expectedType && expectedType !== "any" && !this.sameType(argType, expectedType)) {
            this.diagnostics.error(
              `Argument ${i + 1} of '${node.callee}': expected '${this.formatType(expectedType)}', got '${this.formatType(argType)}'`,
              arg.location
            );
          }
        });
        return signature.returnType;
      }
      case "ArrayLiteral": {
        if (node.elements.length === 0) {
          return { kind: "array", elementType: "any" };
        }
        const elementType = this.inferType(node.elements[0]);
        for (const el of node.elements) {
          const elType = this.inferType(el);
          if (!this.sameType(elType, elementType) && elementType !== "any" && elType !== "any") {
            this.diagnostics.error(
              `Array elements must all have the same type. Found '${this.formatType(elementType)}' and '${this.formatType(elType)}'`,
              el.location
            );
          }
        }
        return { kind: "array", elementType };
      }
      case "ObjectLiteral": {
        const fields = {};
        for (const property of node.properties) {
          fields[property.key] = this.inferType(property.value);
        }
        return { kind: "record", fields };
      }
      case "MemberExpression": {
        const objectType = this.inferType(node.object);
        if (objectType === "any") {
          return "any";
        }
        if (typeof objectType === "object" && objectType.kind === "record") {
          const fieldType = objectType.fields[node.property];
          if (fieldType === void 0) {
            this.diagnostics.error(
              `Property '${node.property}' does not exist on type '${this.formatType(objectType)}'`,
              node.location
            );
            return "any";
          }
          return fieldType;
        }
        this.diagnostics.error(
          `Cannot access property '${node.property}' on non-record type '${this.formatType(objectType)}'`,
          node.location
        );
        return "any";
      }
      case "IndexExpression": {
        const arrayType = this.inferType(node.array);
        const indexType = this.inferType(node.index);
        if (indexType !== "number" && indexType !== "any") {
          this.diagnostics.error(
            `Array index must be a number, got '${this.formatType(indexType)}'`,
            node.index.location
          );
        }
        if (typeof arrayType === "object" && arrayType.kind === "array") {
          return arrayType.elementType;
        }
        if (arrayType === "any") {
          return "any";
        }
        this.diagnostics.error(
          `Cannot index a non-array value of type '${this.formatType(arrayType)}'`,
          node.array.location
        );
        return "any";
      }
      case "BinaryExpression": {
        const leftType = this.inferType(node.left);
        const rightType = this.inferType(node.right);
        if (leftType === "any") return rightType;
        if (rightType === "any") return leftType;
        if (node.operator === "and" || node.operator === "or") {
          if (leftType !== "boolean" || rightType !== "boolean") {
            this.diagnostics.error(
              `Operator '${node.operator}' requires two booleans. Got '${this.formatType(leftType)}' and '${this.formatType(rightType)}'`,
              node.location
            );
          }
          return "boolean";
        }
        if (["==", "!=", "<", "<=", ">", ">="].includes(node.operator)) {
          if (!this.sameType(leftType, rightType)) {
            this.diagnostics.error(
              `Cannot compare '${this.formatType(leftType)}' with '${this.formatType(rightType)}'`,
              node.location
            );
          }
          return "boolean";
        }
        if (node.operator === "+") {
          if (typeof leftType === "object" && leftType.kind === "array") {
            if (typeof rightType === "object" && rightType.kind === "array") {
              if (!this.sameType(leftType.elementType, rightType.elementType)) {
                this.diagnostics.error(
                  `Cannot concatenate arrays of different types: '${this.formatType(leftType.elementType)}[]' + '${this.formatType(rightType.elementType)}[]'`,
                  node.location
                );
              }
              return leftType;
            }
            if (this.sameType(leftType.elementType, rightType)) {
              return leftType;
            }
            this.diagnostics.error(
              `Cannot append '${this.formatType(rightType)}' to array of '${this.formatType(leftType.elementType)}'`,
              node.location
            );
            return leftType;
          }
          if (leftType === "string" || rightType === "string") {
            return "string";
          }
          if (leftType !== "number" || rightType !== "number") {
            this.diagnostics.error(
              `Operator '+' requires numbers, strings, or arrays. Got '${this.formatType(leftType)}' and '${this.formatType(rightType)}'`,
              node.location
            );
          }
          return "number";
        }
        if (leftType !== "number" || rightType !== "number") {
          this.diagnostics.error(
            `Operator '${node.operator}' requires two numbers. Got '${this.formatType(leftType)}' and '${this.formatType(rightType)}'`,
            node.location
          );
        }
        return "number";
      }
      default:
        throw new Error(`Cannot infer type for node type: ${node.type}`);
    }
  }
  sameType(left, right) {
    return sameType(left, right);
  }
  formatType(type) {
    return formatType(type);
  }
};
function checkSource(source, fileName = "<memory>") {
  const ast = new Parser(tokenize(source, fileName)).parseProgram();
  const checker = new TypeChecker();
  const diagnostics = checker.check(ast);
  return { source, ast, diagnostics, binder: checker.getBinder() };
}

// src/state.ts
var documentChecks = /* @__PURE__ */ new Map();
function refresh(document) {
  const result = checkSource(document.getText(), document.uri);
  documentChecks.set(document.uri, result);
  return result;
}
function getCheckResult(uri) {
  return documentChecks.get(uri);
}
function forget(uri) {
  documentChecks.delete(uri);
}

// src/diagnostics.ts
var import_node = require("vscode-languageserver/node.js");
function toLspDiagnostics(diagnostics, document) {
  return diagnostics.map((d) => ({
    severity: d.severity === "error" ? import_node.DiagnosticSeverity.Error : import_node.DiagnosticSeverity.Warning,
    range: {
      start: document.positionAt(d.location.start),
      end: document.positionAt(d.location.end)
    },
    message: d.hint ? `${d.message}
${d.hint}` : d.message,
    source: "raven"
  }));
}

// src/hover.ts
var import_node2 = require("vscode-languageserver/node.js");

// src/symbolAt.ts
function symbolAt(document, position) {
  const result = getCheckResult(document.uri);
  if (!result) return void 0;
  const offset = document.offsetAt(position);
  return result.binder.bindingAt(offset);
}

// src/hover.ts
function formatType2(type) {
  if (type === "any") return "any";
  if (typeof type === "string") return type;
  return `${formatType2(type.elementType)}[]`;
}
function onHover(document, params) {
  const binding = symbolAt(document, params.position);
  if (!binding) return null;
  const keyword = binding.kind === "constant" ? "const" : binding.kind === "parameter" ? "param" : binding.kind === "function" ? "fn" : "let";
  const signature = binding.kind === "function" ? `fn ${binding.name}(...): ${formatType2(binding.type)}` : `${keyword} ${binding.name}: ${formatType2(binding.type)}`;
  return {
    contents: {
      kind: import_node2.MarkupKind.Markdown,
      value: `\`\`\`raven
${signature}
\`\`\``
    }
  };
}

// src/definition.ts
function toLspLocation(uri, loc, document) {
  return {
    uri,
    range: {
      start: document.positionAt(loc.start),
      end: document.positionAt(loc.end)
    }
  };
}
function onDefinition(document, params) {
  const binding = symbolAt(document, params.position);
  if (!binding) return null;
  return toLspLocation(document.uri, binding.declaration, document);
}

// src/references.ts
function toLspLocation2(uri, loc, document) {
  return {
    uri,
    range: {
      start: document.positionAt(loc.start),
      end: document.positionAt(loc.end)
    }
  };
}
function onReferences(document, params) {
  const binding = symbolAt(document, params.position);
  if (!binding) return [];
  const locations = params.context.includeDeclaration ? [binding.declaration, ...binding.references] : binding.references;
  return locations.map((loc) => toLspLocation2(document.uri, loc, document));
}

// src/server.ts
var connection = (0, import_node3.createConnection)(import_node3.ProposedFeatures.all);
var documents = new import_node3.TextDocuments(import_vscode_languageserver_textdocument.TextDocument);
connection.onInitialize((_params) => {
  return {
    capabilities: {
      // Full: re-send the whole document text on every change. Simplest
      // option and plenty fast for how small a Raven file is; incremental
      // sync is a later optimization, not a Milestone 2 concern.
      textDocumentSync: import_node3.TextDocumentSyncKind.Full,
      hoverProvider: true,
      definitionProvider: true,
      referencesProvider: true
    }
  };
});
function validate(document) {
  const result = refresh(document);
  connection.sendDiagnostics({
    uri: document.uri,
    diagnostics: toLspDiagnostics(result.diagnostics, document)
  });
}
documents.onDidChangeContent((event) => validate(event.document));
documents.onDidClose((event) => {
  forget(event.document.uri);
  connection.sendDiagnostics({ uri: event.document.uri, diagnostics: [] });
});
connection.onHover((params) => {
  const document = documents.get(params.textDocument.uri);
  if (!document || !getCheckResult(document.uri)) return null;
  return onHover(document, params);
});
connection.onDefinition((params) => {
  const document = documents.get(params.textDocument.uri);
  if (!document || !getCheckResult(document.uri)) return null;
  return onDefinition(document, params);
});
connection.onReferences((params) => {
  const document = documents.get(params.textDocument.uri);
  if (!document || !getCheckResult(document.uri)) return [];
  return onReferences(document, params);
});
documents.listen(connection);
connection.listen();
