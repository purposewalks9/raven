import { defineConfig } from "tsup";

export default defineConfig({
  entry: ["src/server.ts"],
  format: ["cjs"],
  clean: true,
  // tsup treats real "dependencies" as external by default. @raven/compiler
  // only publishes an ESM "exports" condition, so a plain runtime
  // require("@raven/compiler") from this CJS output fails with
  // ERR_PACKAGE_PATH_NOT_EXPORTED. Bundling it here avoids ever needing
  // Node's CJS resolver to touch it at runtime.
  noExternal: ["@raven/compiler"],
});
